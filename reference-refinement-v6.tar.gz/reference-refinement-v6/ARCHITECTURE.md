# Architecture - Reference Refinement v6.0

## System Architecture

### Overview

Reference Refinement v6.0 implements a **dual-mode microservices architecture** with intelligent client-side routing and serverless-first design.

```
┌──────────────────────────────────────────────────────────┐
│                     Browser (iPad/Desktop)                │
├──────────────────────────────────────────────────────────┤
│                    rr_v60.html (SPA)                      │
│  ┌──────────────────────────────────────────────────┐   │
│  │              Application Layer                    │   │
│  │  • State Management (references array)            │   │
│  │  • UI Components (vanilla JS)                     │   │
│  │  • Event Handlers                                 │   │
│  │  • Data Persistence (localStorage)                │   │
│  └──────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────┐   │
│  │              API Abstraction Layer                │   │
│  │  • APIClient class                                │   │
│  │  • Request routing (standalone/client-server)     │   │
│  │  • Error handling & retry logic                   │   │
│  │  • Response normalization                         │   │
│  └──────────────────────────────────────────────────┘   │
└────────────────────┬─────────────────────────────────────┘
                     │ HTTPS
     ┌───────────────┼───────────────┐
     │               │               │
┌────▼──────┐ ┌─────▼──────┐ ┌─────▼──────┐
│ Standalone│ │   Tunnel   │ │   Local    │
│  (Netlify)│ │(Cloudflare)│ │  (LAN IP)  │
└────┬──────┘ └─────┬──────┘ └─────┬──────┘
     │               │               │
     │          ┌────▼───────────────▼──────┐
     │          │   FastAPI Backend Server   │
     │          │   (backend_server.py)      │
     │          └────────────┬───────────────┘
     │                       │
┌────▼───────────────────────▼──────┐
│     Netlify Functions (Edge)       │
│  ┌──────────────────────────────┐ │
│  │ health.ts                    │ │
│  │ search-google.ts             │ │
│  │ llm-chat.ts                  │ │
│  │ llm-rank.ts                  │ │
│  │ resolve-urls.ts              │ │
│  │ proxy-fetch.ts               │ │
│  └──────────────────────────────┘ │
└────────────────┬───────────────────┘
                 │
┌────────────────▼───────────────────┐
│       External Services             │
│  • Google Custom Search API         │
│  • OpenAI API (GPT-4o-mini)        │
│  • Target websites (URL checking)   │
└─────────────────────────────────────┘
```

## Component Architecture

### Frontend (rr_v60.html)

#### Structure
```javascript
window.app = {
    // State
    references: [],           // Main data array
    filteredReferences: [],   // Current view
    currentEditId: null,      // Active edit
    apiBaseUrl: '',          // Backend URL
    isAdvancedMode: false,   // Mode flag

    // Core Methods
    init(),                  // Initialize app
    loadFile(),             // Parse decisions.txt
    exportFile(),           // Generate output
    applyFilters(),         // Filter/sort data
    
    // UI Methods
    renderReferences(),     // Update display
    editReference(),        // Open edit modal
    showToast(),           // User feedback
    
    // API Methods  
    apiRequest(),          // Unified API caller
    ping(),                // Health check
    generateQueries(),     // LLM query generation
    runSearch(),           // Google search
    rankCandidates(),      // LLM ranking
    verifyUrls(),          // URL checking
}
```

#### State Management
- **Single source of truth**: `references` array
- **Derived state**: `filteredReferences` for display
- **No external dependencies**: Pure JavaScript
- **Persistence**: localStorage for API URL only

#### UI Architecture
- **Component pattern**: Functional UI generation
- **Event delegation**: Single listener per action type
- **Modal system**: Singleton pattern for dialogs
- **Toast notifications**: Queue-based messaging

### Backend Services

#### Netlify Functions (TypeScript)

Each function follows this pattern:

```typescript
import { Handler } from '@netlify/functions';

export const handler: Handler = async (event, context) => {
    // 1. CORS headers
    const headers = { /* CORS config */ };
    
    // 2. Handle OPTIONS preflight
    if (event.httpMethod === 'OPTIONS') return { /* 200 */ };
    
    // 3. Validate method
    if (event.httpMethod !== 'POST') return { /* 405 */ };
    
    // 4. Check configuration
    if (!process.env.API_KEY) return { /* error */ };
    
    // 5. Process request
    try {
        const request = JSON.parse(event.body);
        const result = await processRequest(request);
        return { statusCode: 200, body: JSON.stringify(result) };
    } catch (error) {
        return { statusCode: 200, body: JSON.stringify({ error }) };
    }
};
```

#### FastAPI Backend (Python)

Async architecture with dependency injection:

```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

# Pydantic models for validation
class Request(BaseModel):
    field: str

# Async endpoint handlers
@app.post("/api/endpoint")
async def handler(request: Request):
    try:
        result = await process(request)
        return {"result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

## Data Flow Architecture

### Reference Processing Pipeline

```
1. Load Stage
   decisions.txt → Parser → Reference Objects → State Array

2. Filter Stage  
   State Array → Filter Predicates → Sorted Array → Display

3. Edit Stage
   Reference → Modal Form → Validation → State Update

4. Search Stage
   Reference → LLM Queries → Google Search → Results Array

5. Rank Stage
   Results Array → LLM Ranking → Scored Results → URL Selection

6. Export Stage
   State Array → Serializer → decisions.txt → Download
```

### API Request Flow

```
1. Client Request
   UI Action → API Method → Request Builder

2. Routing Decision
   Standalone? → Relative URL (/api/*)
   Advanced? → Absolute URL (http://backend/api/*)

3. Network Request
   Fetch API → Headers + Body → Backend Service

4. Backend Processing
   Validate → External API → Transform → Response

5. Client Response
   Parse → Error Check → Update UI → User Feedback
```

## Security Architecture

### API Key Management
```
Environment Variables (Never in Code)
         ↓
Backend Services Only
         ↓
Validated on Each Request
         ↓
Rate Limited by Provider
```

### Request Security
- **Input validation**: Pydantic models (Python) / TypeScript types
- **URL validation**: Prevent SSRF attacks
- **CORS policy**: Configurable origins
- **Content Security**: No eval(), no inline scripts
- **XSS prevention**: Text content, not innerHTML

### Data Security
- **No sensitive data client-side**: Only reference text
- **No authentication**: Security through obscurity (URL)
- **HTTPS only**: Encrypted transport
- **Environment isolation**: Separate dev/prod configs

## Performance Architecture

### Optimization Strategies

#### Client-Side
- **Single bundle**: No code splitting needed (<50KB)
- **Lazy rendering**: Virtual scroll for large lists
- **Debounced search**: 300ms delay on typing
- **Optimistic UI**: Update before server confirms
- **Request batching**: Multiple queries in one call

#### Server-Side
- **Async everywhere**: Non-blocking I/O
- **Connection pooling**: Reuse HTTP clients
- **Parallel processing**: Concurrent external API calls
- **Early returns**: Fail fast on errors
- **Timeout protection**: 10s max per request

### Caching Strategy (Future)

```
Client Cache (localStorage)
    ↓ Miss
Server Cache (Netlify Blobs)
    ↓ Miss
External API
    ↓
Update Both Caches
```

## Deployment Architecture

### Netlify Deployment

```
GitHub Repo
    ↓ Push
Netlify Build
    ↓ Install deps
    ↓ Compile TypeScript
    ↓ Deploy functions
    ↓ Deploy static files
CDN Distribution
    ↓
Global Edge Network
```

### Configuration Management

```
.env.template (Version Controlled)
    ↓ Copy
.env (Git Ignored)
    ↓ Load
Environment Variables
    ↓ Read by
Backend Services
```

## Error Handling Architecture

### Error Hierarchy

```
1. Network Errors
   → Retry with exponential backoff
   → Fall back to cached data
   → Show offline message

2. API Errors
   → Parse error response
   → Show specific message
   → Offer alternative action

3. Validation Errors
   → Highlight invalid fields
   → Show inline errors
   → Prevent submission

4. System Errors
   → Log to console
   → Generic user message
   → Maintain app stability
```

### Recovery Patterns

- **Graceful degradation**: Features disable, app continues
- **Progressive enhancement**: Start basic, add features
- **Fallback chains**: Primary → Secondary → Manual
- **State recovery**: Restore from localStorage
- **User guidance**: Clear error messages with actions

## Scalability Architecture

### Vertical Scaling
- **Netlify Functions**: Auto-scales to 1000s concurrent
- **FastAPI**: Scale via workers (uvicorn --workers N)
- **Frontend**: CDN distribution handles load

### Horizontal Scaling
- **Multi-region**: Deploy to multiple Netlify sites
- **Load balancing**: DNS round-robin or Cloudflare
- **Database sharding**: Future - partition by user

### Performance Targets
- **Concurrent users**: 100+ (Netlify), 10-50 (FastAPI)
- **Requests/second**: 1000+ (static), 100+ (API)
- **Response time**: <100ms (static), <500ms (API)
- **Availability**: 99.9% (Netlify SLA)

## Integration Architecture

### External Service Integration

```python
# Adapter Pattern for External APIs
class GoogleSearchAdapter:
    async def search(self, query: str) -> List[Result]:
        response = await http_client.get(GOOGLE_API_URL, params={...})
        return self.transform_response(response)

class OpenAIAdapter:
    async def complete(self, prompt: str) -> str:
        response = await http_client.post(OPENAI_API_URL, json={...})
        return response.json()["choices"][0]["message"]["content"]
```

### Future Integrations
- **Zotero API**: Import/export references
- **CrossRef API**: Validate citations
- **Semantic Scholar**: Enhanced metadata
- **ORCID**: Author disambiguation
- **DOI.org**: Persistent identifiers

## Testing Architecture

### Test Pyramid

```
         ╱ E2E Tests ╲      (5%)
        ╱─────────────╲     Selenium/Playwright
       ╱ Integration  ╲    (20%)
      ╱───────────────╲   API contract tests
     ╱     Unit       ╲  (75%)
    ╱─────────────────╲ Jest/Pytest
```

### Test Strategy
- **Unit tests**: Pure functions, parsers, validators
- **Integration tests**: API endpoints, external services
- **E2E tests**: Critical user paths
- **Performance tests**: Load testing with k6
- **Security tests**: OWASP ZAP scanning

## Monitoring Architecture (Future)

### Observability Stack

```
Application Logs → CloudWatch/Datadog
     ↓
Metrics Collection → Prometheus
     ↓
Dashboards → Grafana
     ↓
Alerts → PagerDuty
```

### Key Metrics
- **API latency**: p50, p95, p99
- **Error rates**: 4xx, 5xx by endpoint
- **External API usage**: Quota consumption
- **User activity**: Daily active users
- **System health**: Memory, CPU, disk

## Development Architecture

### Local Development

```bash
# Frontend only
python -m http.server 8000

# With backend
netlify dev  # Standalone
python backend_server.py  # Client/Server
```

### CI/CD Pipeline

```
Git Push → GitHub Actions
    ↓
Linting (ESLint/Black)
    ↓
Type Checking (TypeScript/mypy)
    ↓
Unit Tests
    ↓
Build
    ↓
Deploy to Netlify
    ↓
Smoke Tests
    ↓
Production
```

## Database Architecture (Future)

### Schema Design

```sql
-- References table
CREATE TABLE references (
    id SERIAL PRIMARY KEY,
    ref_number INTEGER UNIQUE,
    title TEXT,
    authors TEXT,
    year INTEGER,
    publication TEXT,
    relevance VARCHAR(20),
    notes TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- URLs table
CREATE TABLE urls (
    id SERIAL PRIMARY KEY,
    reference_id INTEGER REFERENCES references(id),
    url_type VARCHAR(20),
    url TEXT,
    verified BOOLEAN,
    last_checked TIMESTAMP
);

-- Search queries table
CREATE TABLE queries (
    id SERIAL PRIMARY KEY,
    reference_id INTEGER REFERENCES references(id),
    query TEXT,
    created_at TIMESTAMP
);
```

## Summary

The v6.0 architecture achieves:
- **Simplicity**: Single file frontend, minimal dependencies
- **Flexibility**: Dual-mode operation
- **Scalability**: Serverless auto-scaling
- **Reliability**: Multiple fallback paths
- **Maintainability**: Clear separation of concerns
- **Performance**: Optimized for iPad usage

The architecture is intentionally simple while allowing for future growth through clearly defined extension points.
