# Deployment Checklist - Reference Refinement v6.0

Complete step-by-step deployment guide. Check off each item as you complete it.

## Pre-Deployment Requirements

### Required Accounts
- [ ] **Netlify account** (free tier is fine)
  - Sign up at: https://app.netlify.com/signup
- [ ] **Google Cloud account** (for Search API)
  - Sign up at: https://console.cloud.google.com
- [ ] **OpenAI account** (for GPT-4o-mini)
  - Sign up at: https://platform.openai.com

### Required Software
- [ ] **Node.js 18+** installed
  ```bash
  node --version  # Should show v18.x.x or higher
  ```
- [ ] **Python 3.9+** installed (for client/server mode)
  ```bash
  python3 --version  # Should show 3.9.x or higher
  ```
- [ ] **Git** installed
  ```bash
  git --version
  ```

## Step 1: Obtain API Keys

### Google Custom Search API

- [ ] 1. Go to https://console.cloud.google.com/
- [ ] 2. Create a new project (or select existing)
      - Click "Select Project" → "New Project"
      - Name: "Reference Refinement"
      - Click "Create"
- [ ] 3. Enable Custom Search API
      - Go to "APIs & Services" → "Library"
      - Search for "Custom Search API"
      - Click on it → Click "Enable"
- [ ] 4. Create API credentials
      - Go to "APIs & Services" → "Credentials"
      - Click "Create Credentials" → "API Key"
      - Copy the API key immediately
- [ ] 5. Restrict API key (optional but recommended)
      - Click on the API key
      - Under "API restrictions" → "Restrict key"
      - Select "Custom Search API"
      - Save

**Your Google API Key**: `_________________________`

### Google Search Engine ID

- [ ] 1. Go to https://cse.google.com/cse/all
- [ ] 2. Click "New Search Engine" or "Add"
- [ ] 3. Configure search engine:
      - Search engine name: "Academic References"
      - What to search: "Search the entire web"
      - Or specific sites: `*.edu OR *.org OR *.gov OR scholar.google.com`
- [ ] 4. Click "Create"
- [ ] 5. Click "Control Panel" on the confirmation page
- [ ] 6. Find and copy the "Search engine ID" (cx)

**Your Search Engine ID (cx)**: `_________________________`

### OpenAI API Key

- [ ] 1. Go to https://platform.openai.com/api-keys
- [ ] 2. Click "Create new secret key"
- [ ] 3. Name it: "Reference Refinement"
- [ ] 4. Copy immediately (won't be shown again!)
- [ ] 5. Set up billing if needed:
      - Go to Settings → Billing
      - Add payment method
      - Set monthly limit ($20 suggested)

**Your OpenAI API Key**: `_________________________`

## Step 2: Download the Application

- [ ] 1. Create project directory
  ```bash
  mkdir -p ~/reference-refinement-v6
  cd ~/reference-refinement-v6
  ```

- [ ] 2. Download all files (copy from this project):
  - [ ] `rr_v60.html`
  - [ ] `backend_server.py`
  - [ ] `netlify.toml`
  - [ ] `package.json`
  - [ ] `requirements.txt`
  - [ ] `_redirects`
  - [ ] `.env.template`
  - [ ] `netlify/functions/` directory with all `.ts` files
  - [ ] All `.md` documentation files

## Step 3A: Deploy Standalone Mode (Recommended)

### Install Netlify CLI

- [ ] 1. Install globally
  ```bash
  npm install -g netlify-cli
  ```

- [ ] 2. Verify installation
  ```bash
  netlify --version
  ```

### Login to Netlify

- [ ] 1. Authenticate
  ```bash
  netlify login
  ```
  - This opens a browser
  - Authorize the CLI

### Create and Link Site

- [ ] 1. Initialize new site
  ```bash
  netlify init
  ```
  
- [ ] 2. Choose options:
  - [ ] "Create & configure a new site"
  - [ ] Team: Choose your team (usually your username)
  - [ ] Site name: Enter unique name or leave blank for random
  
- [ ] 3. Note your site info:
  - **Site Name**: `_________________________`
  - **Site ID**: `_________________________`
  - **URL**: `https://YOUR-SITE-NAME.netlify.app`

### Set Environment Variables

- [ ] 1. Set Google API key
  ```bash
  netlify env:set GOOGLE_API_KEY "your-actual-key-here"
  ```

- [ ] 2. Set Google CX
  ```bash
  netlify env:set GOOGLE_CX "your-actual-cx-here"
  ```

- [ ] 3. Set OpenAI key
  ```bash
  netlify env:set OPENAI_API_KEY "your-actual-key-here"
  ```

- [ ] 4. Verify environment variables
  ```bash
  netlify env:list
  ```

### Deploy to Production

- [ ] 1. Deploy the site
  ```bash
  netlify deploy --prod
  ```

- [ ] 2. Wait for deployment (usually 30-60 seconds)

- [ ] 3. Open your site
  ```bash
  netlify open
  ```

### Test Deployment

- [ ] 1. Navigate to your site URL
- [ ] 2. Click "Ping" button → Should show "Connected (v6.0)"
- [ ] 3. Load sample `decisions.txt`
- [ ] 4. Try editing a reference
- [ ] 5. Test "Generate Queries" button
- [ ] 6. Test "Run Search" button
- [ ] 7. Export the file

**✅ Standalone deployment complete!**

## Step 3B: Deploy Client/Server Mode (Optional)

### Python Setup

- [ ] 1. Create virtual environment
  ```bash
  python3 -m venv venv
  source venv/bin/activate  # On Windows: venv\Scripts\activate
  ```

- [ ] 2. Install dependencies
  ```bash
  pip install -r requirements.txt
  ```

### Configure Environment

- [ ] 1. Create .env file
  ```bash
  cp .env.template .env
  ```

- [ ] 2. Edit .env file with your API keys
  ```bash
  nano .env  # or use any text editor
  ```
  
  Add your actual keys:
  ```
  GOOGLE_API_KEY=your-actual-key
  GOOGLE_CX=your-actual-cx
  OPENAI_API_KEY=your-actual-key
  ```

### Run Backend Server

- [ ] 1. Start the server
  ```bash
  python backend_server.py
  ```

- [ ] 2. Verify it's running
  - Open browser to http://localhost:8000
  - Should see API information
  - Check http://localhost:8000/docs for API documentation

### Connect from Frontend

- [ ] 1. Open the deployed Netlify site
- [ ] 2. Toggle to "Advanced" mode
- [ ] 3. Enter backend URL:
  - For local: `http://localhost:8000`
  - For LAN: `http://YOUR-COMPUTER-IP:8000`
- [ ] 4. Click "Set URL"
- [ ] 5. Click "Ping" → Should show "Connected"

### Optional: Cloudflare Tunnel (for remote access)

- [ ] 1. Install cloudflared
  ```bash
  brew install cloudflare/cloudflare/cloudflared  # macOS
  ```

- [ ] 2. Create tunnel
  ```bash
  cloudflared tunnel --url http://localhost:8000
  ```

- [ ] 3. Copy the tunnel URL (looks like `https://xxx.trycloudflare.com`)
- [ ] 4. Use this URL in the frontend's Advanced mode

## Step 4: Verify Everything Works

### Functionality Checklist

- [ ] **Health Check**
  - Ping shows "Connected (v6.0)"
  - No console errors

- [ ] **File Operations**
  - Can load decisions.txt
  - References display correctly
  - Can export modified file

- [ ] **Filtering & Sorting**
  - Relevance filter works
  - Search box filters results
  - Sort options work

- [ ] **Edit Modal**
  - Opens on Edit click
  - All fields editable
  - Save persists changes

- [ ] **AI Features**
  - Generate Queries produces 5-7 queries
  - Run Search returns results
  - Rank Candidates orders results
  - URLs auto-fill

- [ ] **URL Verification**
  - Verify URLs checks accessibility
  - Shows success/error status

## Step 5: Production Configuration

### Performance Optimization

- [ ] 1. Enable Netlify caching (automatic)
- [ ] 2. Set up monitoring:
  ```bash
  netlify functions:log  # Watch function logs
  ```

### Security Hardening

- [ ] 1. Restrict API keys (Google Console)
- [ ] 2. Set spending limits (OpenAI)
- [ ] 3. Configure CORS (if needed):
  - Edit backend_server.py
  - Change `allow_origins=["*"]` to your domain

### Backup Strategy

- [ ] 1. Export decisions.txt regularly
- [ ] 2. Set up automated backups:
  ```bash
  # Add to crontab
  0 2 * * * cp ~/decisions.txt ~/backups/decisions_$(date +%Y%m%d).txt
  ```

## Step 6: Documentation & Training

### User Documentation

- [ ] 1. Bookmark the site on iPad
- [ ] 2. Add to Home Screen for app-like experience
- [ ] 3. Share URL with team members
- [ ] 4. Create quick reference card

### Maintenance Plan

- [ ] 1. Weekly: Check API usage and costs
- [ ] 2. Monthly: Update dependencies
  ```bash
  npm update  # Frontend
  pip install --upgrade -r requirements.txt  # Backend
  ```
- [ ] 3. Quarterly: Review and rotate API keys

## Troubleshooting

### Common Issues

#### "Disconnected" Status
- [ ] Check internet connection
- [ ] Verify API keys are set
- [ ] Try hard refresh (Ctrl+Shift+R)
- [ ] Check Netlify function logs

#### Search Not Working
- [ ] Verify Google API key
- [ ] Check daily quota (100 free)
- [ ] Ensure Search Engine ID is correct
- [ ] Test with simple query

#### LLM Features Failing
- [ ] Verify OpenAI API key
- [ ] Check account has credits
- [ ] Monitor rate limits
- [ ] Try with shorter input

#### Deployment Fails
- [ ] Check Node version (18+)
- [ ] Clear Netlify cache: `netlify deploy --clear`
- [ ] Check function syntax errors
- [ ] Verify netlify.toml format

### Getting Help

1. **Check logs**:
   ```bash
   netlify logs:function  # Serverless logs
   python backend_server.py  # Backend logs (verbose)
   ```

2. **Browser console**: F12 → Console tab

3. **API testing**:
   ```bash
   curl https://your-site.netlify.app/api/health
   ```

## Success Criteria

Your deployment is successful when:

- [ ] ✅ Site loads without errors
- [ ] ✅ Ping shows "Connected (v6.0)"
- [ ] ✅ Can load and save references
- [ ] ✅ Search returns results
- [ ] ✅ AI features work (queries, ranking)
- [ ] ✅ Export produces valid file
- [ ] ✅ Works on iPad Safari
- [ ] ✅ No console errors
- [ ] ✅ Response times under 5 seconds
- [ ] ✅ URL bookmarked on iPad

## Post-Deployment

### Recommended Next Steps

1. Process 5 test references end-to-end
2. Export and verify output format
3. Share with one colleague for feedback
4. Document any custom workflows
5. Set up cost monitoring alerts

### Optimization Tips

1. **Batch similar references** for efficiency
2. **Use filters** to focus on subsets
3. **Export regularly** during long sessions
4. **Monitor API usage** to stay within limits
5. **Cache common searches** mentally

---

**Congratulations!** You've successfully deployed Reference Refinement v6.0.

For daily use, see `IPAD_QUICKSTART.md`.
For technical details, see `ARCHITECTURE.md`.
For troubleshooting, see `README.md`.

**Your deployment URL**: `_________________________`
**Date deployed**: `_________________________`
**Deployed by**: `_________________________`
