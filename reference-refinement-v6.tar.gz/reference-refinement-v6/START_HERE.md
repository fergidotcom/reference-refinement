# START HERE - Reference Refinement v6.0

Welcome! This is your 5-minute orientation to the Reference Refinement system.

## What Is This?

A web application that helps researchers manage, search, and verify academic references with AI assistance.

## Two Ways to Use It

### 1. Easy Way (Standalone - No Setup)
- Everything runs on Netlify's servers
- Access from any browser
- Zero maintenance
- **Best for:** Individual researchers, iPad users

### 2. Power User Way (Client/Server)
- Run backend on your Mac/PC
- Full control over data
- Can use institutional resources
- **Best for:** Teams, heavy users, custom workflows

## Core Features

✅ **Load** your reference list (decisions.txt)  
✅ **Filter & Sort** by relevance, year, or URL status  
✅ **AI Search** - Generate search queries automatically  
✅ **Smart Ranking** - AI ranks search results  
✅ **URL Verification** - Check if links still work  
✅ **Export** updated reference list  

## File You're Working With

```
[123] Smith, J. (2023). Example Paper. Nature.
Relevance: High - Critical for Chapter 3
Primary URL: https://example.com
Q: search query 1
Q: search query 2
```

## Quick Decision Tree

**Just want to try it?** → Use standalone mode  
**Need it for daily work?** → Deploy to Netlify (free)  
**Have special requirements?** → Use client/server mode  
**Working on iPad?** → Standalone is perfect  

## Next Steps

1. **For Setup:** Read `DEPLOYMENT_CHECKLIST.md`
2. **For iPad:** Read `IPAD_QUICKSTART.md`
3. **For Details:** Read `README.md`
4. **For Architecture:** Read `ARCHITECTURE.md`

## One Key Thing to Remember

Version 6.0 replaces the complex 3-terminal setup from v5.5 with simple, robust options that just work.

---

**Ready to start?** → Continue to `IPAD_QUICKSTART.md` for the fastest setup path.
