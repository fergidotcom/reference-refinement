import { Handler } from '@netlify/functions';

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;
const GOOGLE_CX = process.env.GOOGLE_CX;

interface SearchRequest {
  query: string;
  num_results?: number;
}

interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  domain: string;
}

function extractDomain(url: string): string {
  try {
    const parsed = new URL(url);
    return parsed.hostname;
  } catch {
    return url;
  }
}

export const handler: Handler = async (event, context) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Only accept POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  // Check configuration
  if (!GOOGLE_API_KEY || !GOOGLE_CX) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        query: '',
        results: [],
        error: 'Google Search API not configured'
      })
    };
  }

  try {
    // Parse request body
    const request: SearchRequest = JSON.parse(event.body || '{}');
    
    if (!request.query) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Query is required' })
      };
    }

    // Build Google CSE URL
    const params = new URLSearchParams({
      key: GOOGLE_API_KEY,
      cx: GOOGLE_CX,
      q: request.query,
      num: String(request.num_results || 10)
    });

    // Make API request
    const response = await fetch(
      `https://www.googleapis.com/customsearch/v1?${params}`
    );

    if (!response.ok) {
      throw new Error(`Google API error: ${response.status}`);
    }

    const data = await response.json();

    // Parse results
    const results: SearchResult[] = (data.items || []).map((item: any) => ({
      title: item.title || '',
      url: item.link || '',
      snippet: item.snippet || '',
      domain: extractDomain(item.link || '')
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        query: request.query,
        results
      })
    };

  } catch (error) {
    console.error('Search error:', error);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        query: '',
        results: [],
        error: error instanceof Error ? error.message : 'Search failed'
      })
    };
  }
};
