import { Handler } from '@netlify/functions';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

interface Reference {
  title: string;
  authors: string;
  year: string;
  publication?: string;
}

interface SearchCandidate {
  title: string;
  url: string;
  snippet: string;
}

interface RankRequest {
  reference: Reference;
  candidates: SearchCandidate[];
  max_results?: number;
}

interface RankedCandidate {
  url: string;
  title: string;
  score: number;
  reasoning?: string;
}

export const handler: Handler = async (event, context) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Only accept POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  // Check configuration
  if (!OPENAI_API_KEY) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ranked: [],
        error: 'OpenAI API not configured'
      })
    };
  }

  try {
    // Parse request body
    const request: RankRequest = JSON.parse(event.body || '{}');
    
    if (!request.reference || !request.candidates || request.candidates.length === 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Reference and candidates are required' })
      };
    }

    const maxResults = request.max_results || 5;

    // Build ranking prompt
    let prompt = `Given the following academic reference, rank the search results by how likely they are to be the correct source.

Reference:
- Title: ${request.reference.title}
- Authors: ${request.reference.authors}
- Year: ${request.reference.year}
- Publication: ${request.reference.publication || 'Unknown'}

Search Results:
`;

    request.candidates.forEach((candidate, i) => {
      prompt += `\n${i + 1}. ${candidate.title}\n   URL: ${candidate.url}\n   Snippet: ${candidate.snippet}\n`;
    });

    prompt += `\n\nReturn the top ${maxResults} most likely matches as a JSON array with this format:
[{"url": "...", "title": "...", "score": 0.95, "reasoning": "..."}, ...]

The score should be between 0 and 1, with 1 being a perfect match. Return ONLY the JSON array, no additional text.`;

    // Make OpenAI request
    const payload = {
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are an expert at identifying academic references. Analyze the candidates and return only a valid JSON array.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.3,
      max_tokens: 1000
    };

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error?.message || `OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const resultText = data.choices[0].message.content;

    // Parse JSON response
    let ranked: RankedCandidate[] = [];
    
    try {
      // Try to extract JSON from the response
      const jsonMatch = resultText.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        const parsedData = JSON.parse(jsonMatch[0]);
        
        ranked = parsedData.slice(0, maxResults).map((item: any) => ({
          url: item.url || '',
          title: item.title || '',
          score: Number(item.score) || 0,
          reasoning: item.reasoning
        }));
        
        // Sort by score descending
        ranked.sort((a, b) => b.score - a.score);
      }
    } catch (parseError) {
      console.error('Failed to parse LLM response:', parseError);
      
      // Fallback: return candidates in order with decreasing scores
      ranked = request.candidates.slice(0, maxResults).map((candidate, i) => ({
        url: candidate.url,
        title: candidate.title,
        score: 1.0 - (i * 0.15),
        reasoning: 'Fallback ranking due to parse error'
      }));
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ranked
      })
    };

  } catch (error) {
    console.error('LLM ranking error:', error);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ranked: [],
        error: error instanceof Error ? error.message : 'Ranking failed'
      })
    };
  }
};
