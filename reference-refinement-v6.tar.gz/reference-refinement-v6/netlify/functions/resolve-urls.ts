import { Handler } from '@netlify/functions';

interface URLResolveRequest {
  urls: string[];
  check_content?: boolean;
}

interface URLStatus {
  url: string;
  status: 'success' | 'redirect' | 'error';
  final_url?: string;
  status_code?: number;
  error_message?: string;
}

async function checkUrl(url: string): Promise<URLStatus> {
  try {
    // Use HEAD request to check URL without downloading content
    const response = await fetch(url, {
      method: 'HEAD',
      redirect: 'follow',
      signal: AbortSignal.timeout(5000) // 5 second timeout
    });

    // Check if there was a redirect
    const isRedirect = response.redirected;

    return {
      url: url,
      status: isRedirect ? 'redirect' : 'success',
      final_url: isRedirect ? response.url : url,
      status_code: response.status
    };
  } catch (error) {
    // Handle different types of errors
    let errorMessage = 'Unknown error';
    
    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        errorMessage = 'Request timeout';
      } else if (error.message.includes('fetch')) {
        errorMessage = 'Network error';
      } else {
        errorMessage = error.message;
      }
    }

    return {
      url: url,
      status: 'error',
      error_message: errorMessage
    };
  }
}

export const handler: Handler = async (event, context) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Only accept POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Parse request body
    const request: URLResolveRequest = JSON.parse(event.body || '{}');
    
    if (!request.urls || !Array.isArray(request.urls) || request.urls.length === 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'URLs array is required' })
      };
    }

    // Limit number of URLs to check (prevent abuse)
    const urlsToCheck = request.urls.slice(0, 20);

    // Check URLs concurrently
    const results = await Promise.all(
      urlsToCheck.map(url => checkUrl(url))
    );

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        results
      })
    };

  } catch (error) {
    console.error('URL resolution error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: error instanceof Error ? error.message : 'URL resolution failed'
      })
    };
  }
};
