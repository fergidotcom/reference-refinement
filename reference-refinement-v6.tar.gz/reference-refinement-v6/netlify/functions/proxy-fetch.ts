import { Handler } from '@netlify/functions';

export const handler: Handler = async (event, context) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Only accept GET
  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  // Get URL from query parameters
  const url = event.queryStringParameters?.url;

  if (!url) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'URL parameter is required' })
    };
  }

  try {
    // Validate URL
    const parsedUrl = new URL(url);
    
    // Block local/private addresses for security
    const hostname = parsedUrl.hostname.toLowerCase();
    const blockedHosts = ['localhost', '127.0.0.1', '0.0.0.0', '::1'];
    
    if (blockedHosts.includes(hostname) || hostname.startsWith('192.168.') || hostname.startsWith('10.')) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: 'Access to local addresses is forbidden' })
      };
    }

    // Fetch the content
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'User-Agent': 'Reference-Refinement/6.0 (https://github.com/your-repo)'
      },
      signal: AbortSignal.timeout(10000) // 10 second timeout
    });

    if (!response.ok) {
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({
          content: '',
          status_code: response.status,
          headers: {},
          error: `HTTP ${response.status}: ${response.statusText}`
        })
      };
    }

    // Get response content
    const content = await response.text();

    // Extract relevant headers
    const responseHeaders: Record<string, string> = {};
    const relevantHeaders = ['content-type', 'last-modified', 'etag', 'cache-control'];
    
    response.headers.forEach((value, key) => {
      if (relevantHeaders.includes(key.toLowerCase())) {
        responseHeaders[key] = value;
      }
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        content: content,
        status_code: response.status,
        headers: responseHeaders
      })
    };

  } catch (error) {
    console.error('Proxy fetch error:', error);
    
    let errorMessage = 'Fetch failed';
    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        errorMessage = 'Request timeout';
      } else {
        errorMessage = error.message;
      }
    }

    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        content: '',
        status_code: 500,
        headers: {},
        error: errorMessage
      })
    };
  }
};
