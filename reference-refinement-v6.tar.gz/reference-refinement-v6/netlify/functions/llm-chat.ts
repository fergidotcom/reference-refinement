import { Handler } from '@netlify/functions';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

interface ChatRequest {
  prompt: string;
  model?: string;
  temperature?: number;
  max_tokens?: number;
}

export const handler: Handler = async (event, context) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Only accept POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  // Check configuration
  if (!OPENAI_API_KEY) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        result: '',
        model: 'gpt-4o-mini',
        error: 'OpenAI API not configured'
      })
    };
  }

  try {
    // Parse request body
    const request: ChatRequest = JSON.parse(event.body || '{}');
    
    if (!request.prompt) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Prompt is required' })
      };
    }

    // Build OpenAI request
    const payload = {
      model: request.model || 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are a helpful research assistant specializing in academic references.'
        },
        {
          role: 'user',
          content: request.prompt
        }
      ],
      temperature: request.temperature || 0.7,
      max_tokens: request.max_tokens || 1000
    };

    // Make API request
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error?.message || `OpenAI API error: ${response.status}`);
    }

    const data = await response.json();

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        result: data.choices[0].message.content,
        model: request.model || 'gpt-4o-mini',
        tokens_used: data.usage?.total_tokens
      })
    };

  } catch (error) {
    console.error('LLM chat error:', error);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        result: '',
        model: 'gpt-4o-mini',
        error: error instanceof Error ? error.message : 'Chat failed'
      })
    };
  }
};
