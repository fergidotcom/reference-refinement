# Reference Refinement v6.0

A robust dual-mode academic reference management system with LLM-augmented search and ranking capabilities.

## Features

- **Dual-mode operation**: Standalone (Netlify) or Client/Server (FastAPI)
- **LLM-powered**: Automatic query generation and candidate ranking
- **Google Search integration**: Find references across the web
- **iPad-optimized**: Touch-friendly interface with wide dialogs
- **URL verification**: Check and resolve reference URLs
- **Batch operations**: Edit multiple references efficiently
- **Export/Import**: Plain-text format for universal compatibility

## Quick Start

### Option A: Standalone Mode (Recommended)

Zero-terminal deployment via Netlify:

```bash
# One-time setup
npm install -g netlify-cli
netlify login
netlify link --name your-site-name

# Set environment variables
netlify env:set GOOGLE_API_KEY "your-key"
netlify env:set GOOGLE_CX "your-cx"
netlify env:set OPENAI_API_KEY "your-key"

# Deploy
netlify deploy --prod
```

Access at: `https://your-site-name.netlify.app`

### Option B: Client/Server Mode

Single-terminal FastAPI backend:

```bash
# Setup
pip install -r requirements.txt
cp .env.template .env
# Edit .env with your API keys

# Run
python backend_server.py
```

Access at: `http://localhost:8000` (or use Cloudflare tunnel for remote access)

## API Keys

Required services:

1. **Google Custom Search API**
   - Get API key: https://console.cloud.google.com/
   - Create search engine: https://cse.google.com/cse/
   - Free tier: 100 queries/day

2. **OpenAI API**
   - Get API key: https://platform.openai.com/api-keys
   - Model: GPT-4o-mini (cost-effective)
   - ~$0.05 per reference processed

## File Format

The system uses a plain-text `decisions.txt` format:

```
[ID] Authors. (Year). Title. Publication.
Relevance: High|Medium|Low|Remove|Unknown - Optional notes
Primary URL: https://...
Secondary URL: https://...
Tertiary URL: https://...
Q: Search query 1
Q: Search query 2
```

## Workflow

1. **Load** - Import your decisions.txt file
2. **Filter** - Find references by relevance, URL status, or search
3. **Edit** - Update relevance and notes
4. **Search** - Generate queries with AI, search Google
5. **Rank** - Let AI rank search results by relevance
6. **Verify** - Check if URLs are still accessible
7. **Export** - Download updated decisions.txt

## User Interface

### Main View
- **Header**: Version, mode toggle, connection status
- **Controls**: File operations, filters, sorting
- **Stats Bar**: Reference counts by category
- **Grid**: Reference cards with inline actions

### Edit Modal
- **Basic Info**: Title, authors, year, publication
- **Relevance**: Level and notes
- **URLs**: Primary, secondary, tertiary with verification
- **Search**: AI-powered query generation and ranking

## Architecture

```
Frontend (rr_v60.html)
    ↓
API Layer (/api/*)
    ↓
Backend (Netlify Functions OR FastAPI)
    ↓
External Services (Google CSE, OpenAI)
```

## Configuration

### Environment Variables

```bash
GOOGLE_API_KEY=your-google-api-key
GOOGLE_CX=your-custom-search-engine-id
OPENAI_API_KEY=your-openai-api-key
```

### Netlify Configuration

See `netlify.toml` for build settings and redirects.

### Python Configuration

See `requirements.txt` for dependencies.

## Development

### Local Testing

**Standalone mode:**
```bash
netlify dev
```

**Client/Server mode:**
```bash
python backend_server.py
```

### Project Structure

```
reference-refinement-v6/
├── rr_v60.html              # Frontend application
├── backend_server.py        # FastAPI backend
├── netlify/
│   └── functions/          # Serverless functions
│       ├── health.ts
│       ├── search-google.ts
│       ├── llm-chat.ts
│       ├── llm-rank.ts
│       ├── resolve-urls.ts
│       └── proxy-fetch.ts
├── netlify.toml            # Netlify configuration
├── package.json            # Node dependencies
├── requirements.txt        # Python dependencies
├── _redirects             # URL routing
├── .env.template          # Environment template
└── decisions.txt          # Sample data file
```

## Troubleshooting

### Connection Issues

1. Check health endpoint: `/api/health`
2. Verify API keys are set correctly
3. Check browser console for errors
4. Ensure backend is running (client/server mode)

### Search Not Working

1. Verify Google API key and CX
2. Check daily quota (100 free searches)
3. Test with simple queries first

### LLM Features Failing

1. Verify OpenAI API key
2. Check API credit balance
3. Monitor rate limits

### URL Verification Fails

1. Some sites block automated checks
2. Try manual verification
3. Check for CORS issues

## Performance

- **Search latency**: 200-500ms per query
- **LLM query generation**: 2-3 seconds
- **LLM ranking**: 3-4 seconds
- **URL verification**: 1-2 seconds per URL
- **File parsing**: <100ms for 1000 references

## Security

- API keys stored as environment variables
- CORS configured for production domains
- URL validation prevents SSRF attacks
- No sensitive data stored client-side

## Browser Support

- Safari (iOS/macOS) - Primary target
- Chrome/Edge - Fully supported
- Firefox - Fully supported
- Mobile browsers - Touch optimized

## Cost Estimation

Monthly costs for moderate usage (200 references/month):

- **Netlify hosting**: Free tier
- **Google Search**: ~$5 (after free tier)
- **OpenAI API**: ~$10
- **Total**: ~$15/month

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - See LICENSE file for details

## Support

- Documentation: See `/docs` folder
- Issues: GitHub Issues
- Updates: Check releases page

## Version History

- **v6.0** (2024-01) - Dual-mode architecture, TypeScript functions
- **v5.5** (2023-12) - Initial stable release
- **v5.0** (2023-11) - Beta testing

## Acknowledgments

- Built for academic researchers
- Optimized for iPad Pro workflow
- Designed for bibliography management
