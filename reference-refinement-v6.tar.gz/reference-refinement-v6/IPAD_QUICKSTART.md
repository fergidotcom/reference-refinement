# iPad Quick Start - Reference Refinement v6.0

Get up and running in 15 minutes on your iPad.

## Option 1: Use Deployed Version (Fastest)

### Step 1: Open Safari
Navigate to: `https://rrv521-1760738877.netlify.app`

### Step 2: Test Connection
1. Tap **"Ping"** button in header
2. Should show green "Connected (v6.0)"
3. If red, check internet connection

### Step 3: Load Your References
1. Tap **"Choose File"**
2. Select your `decisions.txt` from:
   - iCloud Drive
   - Dropbox
   - Local Files
3. References appear instantly

### Step 4: Start Working
- **Filter**: Use dropdowns to show only what you need
- **Search**: Type in search box for instant results
- **Edit**: Tap any reference card, then "Edit"
- **Export**: Tap "Export" to save changes

**That's it! You're working in under 2 minutes.**

---

## Option 2: Deploy Your Own (Recommended)

### Prerequisites
You'll need:
- Mac with Terminal
- Netlify account (free)
- API keys (instructions below)

### Step 1: Get API Keys (10 minutes)

#### Google Search API
1. Go to https://console.cloud.google.com/
2. Create new project (or select existing)
3. Enable "Custom Search API"
4. Create credentials → API Key
5. Copy your API key

#### Google Search Engine ID
1. Go to https://cse.google.com/cse/all
2. Click "Add" to create new engine
3. Enter `*.edu OR *.org OR *.gov` for academic sites
4. Copy the Search Engine ID (cx)

#### OpenAI API
1. Go to https://platform.openai.com/api-keys
2. Create new secret key
3. Copy immediately (won't show again)

### Step 2: Deploy to Netlify (5 minutes)

On your Mac, open Terminal:

```bash
# Navigate to the project
cd ~/Library/CloudStorage/Dropbox/Fergi/AI\ Wrangling/References/reference-refinement-v6

# Install Netlify CLI (first time only)
npm install -g netlify-cli

# Login to Netlify (first time only)
netlify login

# Create new site
netlify init
# Choose: "Create & configure a new site"
# Team: Select your team
# Site name: Enter unique name or leave blank for random

# Set your API keys
netlify env:set GOOGLE_API_KEY "your-google-api-key"
netlify env:set GOOGLE_CX "your-google-cx"
netlify env:set OPENAI_API_KEY "your-openai-api-key"

# Deploy
netlify deploy --prod

# Get your URL
netlify open
```

### Step 3: Access from iPad

1. Copy your Netlify URL (looks like `https://amazing-site-123.netlify.app`)
2. Open Safari on iPad
3. Navigate to your URL
4. Bookmark it (tap Share → Add to Home Screen)

---

## Daily iPad Workflow

### Morning Setup (30 seconds)
1. Tap app icon (if saved to home screen)
2. Load your decisions.txt
3. Check stats bar for overview

### Processing References

#### Quick Review
1. Set filter to "Relevance: Unknown"
2. Tap first reference → Edit
3. Set relevance level
4. Add notes if needed
5. Save → Next reference

#### Find and Verify URLs
1. Tap reference → Edit
2. Tap "Generate Queries (AI)" - wait 3 seconds
3. Tap "Run Search" - wait 5 seconds
4. Review results (checkboxes auto-selected)
5. Tap "Rank Candidates (AI)"
6. Top URLs auto-fill into form
7. Tap "Verify All URLs"
8. Save

#### Batch Operations
1. Use search box to find related references
2. Process them as a group
3. Export when batch is complete

### End of Session
1. Tap "Export" button
2. Choose save location:
   - iCloud Drive (recommended)
   - Dropbox
   - Local Downloads
3. File named with today's date

---

## iPad-Specific Tips

### Touch Gestures
- **Tap** reference card to select
- **Double-tap** to quick edit
- **Swipe left** on search result to dismiss
- **Pull down** to refresh connection

### Keyboard Shortcuts (with external keyboard)
- `⌘S` - Save current edit
- `⌘F` - Focus search box
- `⌘E` - Export file
- `Escape` - Close modal

### Safari Settings for Best Experience
1. Settings → Safari
2. Turn OFF "Prevent Cross-Site Tracking"
3. Turn ON "Desktop Website" for this site
4. Clear website data if having issues

### Offline Capability
- ✅ View loaded references
- ✅ Edit relevance and notes
- ✅ Filter and sort
- ❌ Search (requires internet)
- ❌ AI features (requires internet)
- ❌ URL verification (requires internet)

---

## Troubleshooting

### "Disconnected" Status
- Check WiFi connection
- Try different network
- Hard refresh: Hold refresh button → "Reload Without Cache"

### File Won't Load
- Check file format (must be .txt)
- Ensure proper encoding (UTF-8)
- Try smaller test file first

### Search Not Working
- Verify API keys are set (deployment step)
- Check daily quota (100 free searches)
- Try simpler query

### Modal Too Small
- Rotate iPad to landscape
- Pinch to zoom out slightly
- Check Safari zoom settings

### Changes Not Saving
- Always tap "Save" in edit modal
- Export regularly during work
- Check available storage

---

## Performance Tips

### For Large Files (500+ references)
1. Use filters aggressively
2. Process in batches of 20-30
3. Export after each batch
4. Close other Safari tabs

### For Faster Searches
1. Keep queries short (3-5 words)
2. Use author + year + keyword
3. Run 3-5 queries max per reference
4. Reuse queries for similar references

### Battery Optimization
- Reduce screen brightness
- Close modal when not editing
- Export and close tab during breaks
- Use Reader Mode for reviewing

---

## Quick Reference Card

| Action | How |
|--------|-----|
| Load file | Choose File button |
| Filter | Dropdown menus |
| Search | Type in search box |
| Edit | Tap card → Edit |
| Generate queries | Edit → Generate Queries |
| Search web | Edit → Run Search |
| Rank results | Edit → Rank Candidates |
| Verify URLs | Edit → Verify URLs |
| Save changes | Save button in modal |
| Export | Export button → Save |

---

## Pro Tips

1. **Morning routine**: Load → Filter "Unknown" → Process 10 → Export
2. **Batch similar**: Search author name → Process all their works together
3. **Quick verify**: Generate queries → Run search → Rank → Save (under 30s)
4. **Safety first**: Export after every 20 edits
5. **Speed mode**: Use "Quick Search" button on cards

---

## Need More Help?

- **Setup issues**: See `DEPLOYMENT_CHECKLIST.md`
- **Technical details**: See `ARCHITECTURE.md`
- **General usage**: See `README.md`
- **What's new**: See `IMPLEMENTATION_SUMMARY.md`

---

**Ready to process references?** Load your file and start with the first "Unknown" relevance item!
